'use strict';

require('dotenv').config();